<html class="">

<head>


    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
    window.FontAwesomeConfig = {
        autoReplaceSvg: 'nest', // Options: 'nest', 'remove', 'replace'
    };
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js" crossorigin="anonymous"
        referrerpolicy="no-referrer"></script>


    <style>
    * {
        font-family: 'Inter', sans-serif;
    }

    ::-webkit-scrollbar {
        display: none;
    }
    </style>


    <style>
    .highlighted-section {
        outline: 2px solid #3F20FB;
        background-color: rgba(63, 32, 251, 0.1);
    }

    .edit-button {
        position: absolute;
        z-index: 1000;
    }
    </style>


    <style>
    :root {
        /* Base colors */
        --color-base: #ffffff;
        --color-base-50: #f9fafb;
        --color-base-100: #f3f4f6;
        --color-base-200: #e5e7eb;
        --color-base-300: #d1d5db;
        --color-base-400: #9ca3af;
        --color-base-500: #6b7280;
        --color-base-600: #4b5563;
        --color-base-700: #374151;
        --color-base-800: #1f2937;
        --color-base-900: #111827;
        --color-base-content: #1f2937;

        /* Primary colors */
        --color-primary: #3b82f6;
        --color-primary-50: #eff6ff;
        --color-primary-100: #dbeafe;
        --color-primary-200: #bfdbfe;
        --color-primary-300: #93c5fd;
        --color-primary-400: #60a5fa;
        --color-primary-500: #3b82f6;
        --color-primary-600: #2563eb;
        --color-primary-700: #1d4ed8;
        --color-primary-800: #1e40af;
        --color-primary-900: #1e3a8a;
        --color-primary-focus: #2563eb;
        --color-primary-content: #ffffff;

        /* Secondary colors */
        --color-secondary: #8b5cf6;
        --color-secondary-50: #f5f3ff;
        --color-secondary-100: #ede9fe;
        --color-secondary-200: #ddd6fe;
        --color-secondary-300: #c4b5fd;
        --color-secondary-400: #a78bfa;
        --color-secondary-500: #8b5cf6;
        --color-secondary-600: #7c3aed;
        --color-secondary-700: #6d28d9;
        --color-secondary-800: #5b21b6;
        --color-secondary-900: #4c1d95;
        --color-secondary-focus: #7c3aed;
        --color-secondary-content: #ffffff;

        /* Accent colors */
        --color-accent: #f472b6;
        --color-accent-50: #fdf2f8;
        --color-accent-100: #fce7f3;
        --color-accent-200: #fbcfe8;
        --color-accent-300: #f9a8d4;
        --color-accent-400: #f472b6;
        --color-accent-500: #ec4899;
        --color-accent-600: #db2777;
        --color-accent-700: #be185d;
        --color-accent-800: #9d174d;
        --color-accent-900: #831843;
        --color-accent-focus: #db2777;
        --color-accent-content: #ffffff;

        /* Neutral colors */
        --color-neutral: #6b7280;
        --color-neutral-50: #f9fafb;
        --color-neutral-100: #f3f4f6;
        --color-neutral-200: #e5e7eb;
        --color-neutral-300: #d1d5db;
        --color-neutral-400: #9ca3af;
        --color-neutral-500: #6b7280;
        --color-neutral-600: #4b5563;
        --color-neutral-700: #374151;
        --color-neutral-800: #1f2937;
        --color-neutral-900: #111827;
        --color-neutral-focus: #4b5563;
        --color-neutral-content: #ffffff;

        /* Info colors */
        --color-info: #3b82f6;
        --color-info-50: #eff6ff;
        --color-info-100: #dbeafe;
        --color-info-200: #bfdbfe;
        --color-info-300: #93c5fd;
        --color-info-400: #60a5fa;
        --color-info-500: #3b82f6;
        --color-info-600: #2563eb;
        --color-info-700: #1d4ed8;
        --color-info-800: #1e40af;
        --color-info-900: #1e3a8a;
        --color-info-focus: #2563eb;
        --color-info-content: #ffffff;

        /* Success colors */
        --color-success: #10b981;
        --color-success-50: #ecfdf5;
        --color-success-100: #d1fae5;
        --color-success-200: #a7f3d0;
        --color-success-300: #6ee7b7;
        --color-success-400: #34d399;
        --color-success-500: #10b981;
        --color-success-600: #059669;
        --color-success-700: #047857;
        --color-success-800: #065f46;
        --color-success-900: #064e3b;
        --color-success-focus: #059669;
        --color-success-content: #ffffff;

        /* Warning colors */
        --color-warning: #f59e0b;
        --color-warning-50: #fffbeb;
        --color-warning-100: #fef3c7;
        --color-warning-200: #fde68a;
        --color-warning-300: #fcd34d;
        --color-warning-400: #fbbf24;
        --color-warning-500: #f59e0b;
        --color-warning-600: #d97706;
        --color-warning-700: #b45309;
        --color-warning-800: #92400e;
        --color-warning-900: #78350f;
        --color-warning-focus: #d97706;
        --color-warning-content: #ffffff;

        /* Error colors */
        --color-error: #ef4444;
        --color-error-50: #fef2f2;
        --color-error-100: #fee2e2;
        --color-error-200: #fecaca;
        --color-error-300: #fca5a5;
        --color-error-400: #f87171;
        --color-error-500: #ef4444;
        --color-error-600: #dc2626;
        --color-error-700: #b91c1c;
        --color-error-800: #991b1b;
        --color-error-900: #7f1d1d;
        --color-error-focus: #dc2626;
        --color-error-content: #ffffff;
    }
    </style>


    <style>
    /* Dark theme */
    .dark {
        /* Base colors */
        --color-base: #1f2937;
        --color-base-50: #111827;
        --color-base-100: #1f2937;
        --color-base-200: #374151;
        --color-base-300: #4b5563;
        --color-base-400: #6b7280;
        --color-base-500: #9ca3af;
        --color-base-600: #d1d5db;
        --color-base-700: #e5e7eb;
        --color-base-800: #f3f4f6;
        --color-base-900: #f9fafb;
        --color-base-content: #f9fafb;

        /* Primary colors */
        --color-primary: #60a5fa;
        --color-primary-50: #1e3a8a;
        --color-primary-100: #1e40af;
        --color-primary-200: #1d4ed8;
        --color-primary-300: #2563eb;
        --color-primary-400: #3b82f6;
        --color-primary-500: #60a5fa;
        --color-primary-600: #93c5fd;
        --color-primary-700: #bfdbfe;
        --color-primary-800: #dbeafe;
        --color-primary-900: #eff6ff;
        --color-primary-focus: #3b82f6;
        --color-primary-content: #1f2937;

        /* Secondary colors */
        --color-secondary: #a78bfa;
        --color-secondary-50: #4c1d95;
        --color-secondary-100: #5b21b6;
        --color-secondary-200: #6d28d9;
        --color-secondary-300: #7c3aed;
        --color-secondary-400: #8b5cf6;
        --color-secondary-500: #a78bfa;
        --color-secondary-600: #c4b5fd;
        --color-secondary-700: #ddd6fe;
        --color-secondary-800: #ede9fe;
        --color-secondary-900: #f5f3ff;
        --color-secondary-focus: #8b5cf6;
        --color-secondary-content: #1f2937;

        /* Accent colors */
        --color-accent: #f472b6;
        --color-accent-50: #831843;
        --color-accent-100: #9d174d;
        --color-accent-200: #be185d;
        --color-accent-300: #db2777;
        --color-accent-400: #ec4899;
        --color-accent-500: #f472b6;
        --color-accent-600: #f9a8d4;
        --color-accent-700: #fbcfe8;
        --color-accent-800: #fce7f3;
        --color-accent-900: #fdf2f8;
        --color-accent-focus: #ec4899;
        --color-accent-content: #1f2937;

        /* Neutral colors remain the same as light theme */

        /* Info colors */
        --color-info: #60a5fa;
        --color-info-50: #1e3a8a;
        --color-info-100: #1e40af;
        --color-info-200: #1d4ed8;
        --color-info-300: #2563eb;
        --color-info-400: #3b82f6;
        --color-info-500: #60a5fa;
        --color-info-600: #93c5fd;
        --color-info-700: #bfdbfe;
        --color-info-800: #dbeafe;
        --color-info-900: #eff6ff;
        --color-info-focus: #3b82f6;
        --color-info-content: #1f2937;

        /* Success colors */
        --color-success: #34d399;
        --color-success-50: #064e3b;
        --color-success-100: #065f46;
        --color-success-200: #047857;
        --color-success-300: #059669;
        --color-success-400: #10b981;
        --color-success-500: #34d399;
        --color-success-600: #6ee7b7;
        --color-success-700: #a7f3d0;
        --color-success-800: #d1fae5;
        --color-success-900: #ecfdf5;
        --color-success-focus: #10b981;
        --color-success-content: #1f2937;

        /* Warning colors */
        --color-warning: #fbbf24;
        --color-warning-50: #78350f;
        --color-warning-100: #92400e;
        --color-warning-200: #b45309;
        --color-warning-300: #d97706;
        --color-warning-400: #f59e0b;
        --color-warning-500: #fbbf24;
        --color-warning-600: #fcd34d;
        --color-warning-700: #fde68a;
        --color-warning-800: #fef3c7;
        --color-warning-900: #fffbeb;
        --color-warning-focus: #f59e0b;
        --color-warning-content: #1f2937;

        /* Error colors */
        --color-error: #f87171;
        --color-error-50: #7f1d1d;
        --color-error-100: #991b1b;
        --color-error-200: #b91c1c;
        --color-error-300: #dc2626;
        --color-error-400: #ef4444;
        --color-error-500: #f87171;
        --color-error-600: #fca5a5;
        --color-error-700: #fecaca;
        --color-error-800: #fee2e2;
        --color-error-900: #fef2f2;
        --color-error-focus: #ef4444;
        --color-error-content: #1f2937;
    }
    </style>


    <script>
    tailwind.config = {
        "theme": {
            "extend": {
                "colors": {
                    "transparent": "transparent",
                    "current": "currentColor",
                    "black": "#000000",
                    "white": "#ffffff",
                    "gray": {
                        "50": "#f9fafb",
                        "100": "#f3f4f6",
                        "200": "#e5e7eb",
                        "300": "#d1d5db",
                        "400": "#9ca3af",
                        "500": "#6b7280",
                        "600": "#4b5563",
                        "700": "#374151",
                        "800": "#1f2937",
                        "900": "#111827"
                    },
                    "red": {
                        "50": "#fef2f2",
                        "100": "#fee2e2",
                        "200": "#fecaca",
                        "300": "#fca5a5",
                        "400": "#f87171",
                        "500": "#ef4444",
                        "600": "#dc2626",
                        "700": "#b91c1c",
                        "800": "#991b1b",
                        "900": "#7f1d1d"
                    },
                    "yellow": {
                        "50": "#fffbeb",
                        "100": "#fef3c7",
                        "200": "#fde68a",
                        "300": "#fcd34d",
                        "400": "#fbbf24",
                        "500": "#f59e0b",
                        "600": "#d97706",
                        "700": "#b45309",
                        "800": "#92400e",
                        "900": "#78350f"
                    },
                    "green": {
                        "50": "#ecfdf5",
                        "100": "#d1fae5",
                        "200": "#a7f3d0",
                        "300": "#6ee7b7",
                        "400": "#34d399",
                        "500": "#10b981",
                        "600": "#059669",
                        "700": "#047857",
                        "800": "#065f46",
                        "900": "#064e3b"
                    },
                    "blue": {
                        "50": "#eff6ff",
                        "100": "#dbeafe",
                        "200": "#bfdbfe",
                        "300": "#93c5fd",
                        "400": "#60a5fa",
                        "500": "#3b82f6",
                        "600": "#2563eb",
                        "700": "#1d4ed8",
                        "800": "#1e40af",
                        "900": "#1e3a8a"
                    },
                    "indigo": {
                        "50": "#eef2ff",
                        "100": "#e0e7ff",
                        "200": "#c7d2fe",
                        "300": "#a5b4fc",
                        "400": "#818cf8",
                        "500": "#6366f1",
                        "600": "#4f46e5",
                        "700": "#4338ca",
                        "800": "#3730a3",
                        "900": "#312e81"
                    },
                    "purple": {
                        "50": "#f5f3ff",
                        "100": "#ede9fe",
                        "200": "#ddd6fe",
                        "300": "#c4b5fd",
                        "400": "#a78bfa",
                        "500": "#8b5cf6",
                        "600": "#7c3aed",
                        "700": "#6d28d9",
                        "800": "#5b21b6",
                        "900": "#4c1d95"
                    },
                    "pink": {
                        "50": "#fdf2f8",
                        "100": "#fce7f3",
                        "200": "#fbcfe8",
                        "300": "#f9a8d4",
                        "400": "#f472b6",
                        "500": "#ec4899",
                        "600": "#db2777",
                        "700": "#be185d",
                        "800": "#9d174d",
                        "900": "#831843"
                    },
                    "primary": {
                        "50": "var(--color-primary-50)",
                        "100": "var(--color-primary-100)",
                        "200": "var(--color-primary-200)",
                        "300": "var(--color-primary-300)",
                        "400": "var(--color-primary-400)",
                        "500": "var(--color-primary-500)",
                        "600": "var(--color-primary-600)",
                        "700": "var(--color-primary-700)",
                        "800": "var(--color-primary-800)",
                        "900": "var(--color-primary-900)",
                        "DEFAULT": "var(--color-primary)",
                        "focus": "var(--color-primary-focus)",
                        "content": "var(--color-primary-content)"
                    },
                    "secondary": {
                        "50": "var(--color-secondary-50)",
                        "100": "var(--color-secondary-100)",
                        "200": "var(--color-secondary-200)",
                        "300": "var(--color-secondary-300)",
                        "400": "var(--color-secondary-400)",
                        "500": "var(--color-secondary-500)",
                        "600": "var(--color-secondary-600)",
                        "700": "var(--color-secondary-700)",
                        "800": "var(--color-secondary-800)",
                        "900": "var(--color-secondary-900)",
                        "DEFAULT": "var(--color-secondary)",
                        "focus": "var(--color-secondary-focus)",
                        "content": "var(--color-secondary-content)"
                    },
                    "accent": {
                        "50": "var(--color-accent-50)",
                        "100": "var(--color-accent-100)",
                        "200": "var(--color-accent-200)",
                        "300": "var(--color-accent-300)",
                        "400": "var(--color-accent-400)",
                        "500": "var(--color-accent-500)",
                        "600": "var(--color-accent-600)",
                        "700": "var(--color-accent-700)",
                        "800": "var(--color-accent-800)",
                        "900": "var(--color-accent-900)",
                        "DEFAULT": "var(--color-accent)",
                        "focus": "var(--color-accent-focus)",
                        "content": "var(--color-accent-content)"
                    },
                    "neutral": {
                        "50": "var(--color-neutral-50)",
                        "100": "var(--color-neutral-100)",
                        "200": "var(--color-neutral-200)",
                        "300": "var(--color-neutral-300)",
                        "400": "var(--color-neutral-400)",
                        "500": "var(--color-neutral-500)",
                        "600": "var(--color-neutral-600)",
                        "700": "var(--color-neutral-700)",
                        "800": "var(--color-neutral-800)",
                        "900": "var(--color-neutral-900)",
                        "DEFAULT": "var(--color-neutral)",
                        "focus": "var(--color-neutral-focus)",
                        "content": "var(--color-neutral-content)"
                    },
                    "info": {
                        "50": "var(--color-info-50)",
                        "100": "var(--color-info-100)",
                        "200": "var(--color-info-200)",
                        "300": "var(--color-info-300)",
                        "400": "var(--color-info-400)",
                        "500": "var(--color-info-500)",
                        "600": "var(--color-info-600)",
                        "700": "var(--color-info-700)",
                        "800": "var(--color-info-800)",
                        "900": "var(--color-info-900)",
                        "DEFAULT": "var(--color-info)",
                        "focus": "var(--color-info-focus)",
                        "content": "var(--color-info-content)"
                    },
                    "success": {
                        "50": "var(--color-success-50)",
                        "100": "var(--color-success-100)",
                        "200": "var(--color-success-200)",
                        "300": "var(--color-success-300)",
                        "400": "var(--color-success-400)",
                        "500": "var(--color-success-500)",
                        "600": "var(--color-success-600)",
                        "700": "var(--color-success-700)",
                        "800": "var(--color-success-800)",
                        "900": "var(--color-success-900)",
                        "DEFAULT": "var(--color-success)",
                        "focus": "var(--color-success-focus)",
                        "content": "var(--color-success-content)"
                    },
                    "warning": {
                        "50": "var(--color-warning-50)",
                        "100": "var(--color-warning-100)",
                        "200": "var(--color-warning-200)",
                        "300": "var(--color-warning-300)",
                        "400": "var(--color-warning-400)",
                        "500": "var(--color-warning-500)",
                        "600": "var(--color-warning-600)",
                        "700": "var(--color-warning-700)",
                        "800": "var(--color-warning-800)",
                        "900": "var(--color-warning-900)",
                        "DEFAULT": "var(--color-warning)",
                        "focus": "var(--color-warning-focus)",
                        "content": "var(--color-warning-content)"
                    },
                    "error": {
                        "50": "var(--color-error-50)",
                        "100": "var(--color-error-100)",
                        "200": "var(--color-error-200)",
                        "300": "var(--color-error-300)",
                        "400": "var(--color-error-400)",
                        "500": "var(--color-error-500)",
                        "600": "var(--color-error-600)",
                        "700": "var(--color-error-700)",
                        "800": "var(--color-error-800)",
                        "900": "var(--color-error-900)",
                        "DEFAULT": "var(--color-error)",
                        "focus": "var(--color-error-focus)",
                        "content": "var(--color-error-content)"
                    },
                    "danger": {
                        "50": "var(--color-error-50)",
                        "100": "var(--color-error-100)",
                        "200": "var(--color-error-200)",
                        "300": "var(--color-error-300)",
                        "400": "var(--color-error-400)",
                        "500": "var(--color-error-500)",
                        "600": "var(--color-error-600)",
                        "700": "var(--color-error-700)",
                        "800": "var(--color-error-800)",
                        "900": "var(--color-error-900)",
                        "DEFAULT": "var(--color-error)",
                        "focus": "var(--color-error-focus)",
                        "content": "var(--color-error-content)"
                    },
                    "failure": {
                        "50": "var(--color-error-50)",
                        "100": "var(--color-error-100)",
                        "200": "var(--color-error-200)",
                        "300": "var(--color-error-300)",
                        "400": "var(--color-error-400)",
                        "500": "var(--color-error-500)",
                        "600": "var(--color-error-600)",
                        "700": "var(--color-error-700)",
                        "800": "var(--color-error-800)",
                        "900": "var(--color-error-900)",
                        "DEFAULT": "var(--color-error)",
                        "focus": "var(--color-error-focus)",
                        "content": "var(--color-error-content)"
                    }
                },
                "fontFamily": {
                    "sans": [
                        "Inter",
                        "sans-serif"
                    ]
                }
            }
        },
        "variants": {
            "extend": {
                "backgroundColor": [
                    "active",
                    "group-hover"
                ],
                "textColor": [
                    "active",
                    "group-hover"
                ]
            }
        },
        "plugins": []
    };
    </script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;500;600;700;800;900&amp;display=swap">
    <style>
    .highlighted-section {
        outline: 2px solid #3F20FB;
        background-color: rgba(63, 32, 251, 0.1);
    }

    .edit-button {
        position: absolute;
        z-index: 1000;
    }

    ::-webkit-scrollbar {
        display: none;
    }

    html,
    body {
        -ms-overflow-style: none;
        scrollbar-width: none;
    }
    </style>
</head>

<body class="h-full text-base-content">
    <div class="container mx-auto px-6 py-4 flex items-center justify-between">
        <div class="flex items-center space-x-2">
            <i class="fa-solid fa-users-gear text-neutral-800 text-2xl"></i>
            <span class="text-xl text-neutral-800">HR Solutions</span>
        </div>
        <nav class="hidden md:flex items-center space-x-8">
            <span class="text-neutral-700 hover:text-neutral-900 cursor-pointer"><a
                    href="<?php echo route_to('site.home');?>">Início</a></span>
            <span class="text-neutral-700 hover:text-neutral-900 cursor-pointer"><a
                    href="<?php echo route_to('site.sobre');?>">Quem Somos</a></span>
            <span class="text-neutral-700 hover:text-neutral-900 cursor-pointer"><a
                    href="<?php echo route_to('site.servicos');?>">Serviços</a></span>
            <span class="text-neutral-700 hover:text-neutral-900 cursor-pointer"><a
                    href="<?php echo route_to('site.vagas');?>">Vagas</a></span>
            <span class="text-neutral-700 hover:text-neutral-900 cursor-pointer"><a
                    href="<?php echo route_to('site.sobre');?>">Clientes</a></span>
            <span class="text-neutral-700 hover:text-neutral-900 cursor-pointer"><a
                    href="<?php echo route_to('site.contato');?>">Contato
                </a></span>
        </nav>
        <div class="flex items-center space-x-4">
            <span
                class="hidden md:block px-4 py-2 border border-neutral-300 rounded-md text-neutral-700 hover:bg-neutral-50 cursor-pointer"><a
                    href="<?php echo route_to('site.cadastre');?>">Enviar
                    Currículo</a></span>
            <button class="md:hidden text-neutral-700">
                <i class="fa-solid fa-bars text-xl"></i>
            </button>
        </div>
    </div>


    <main>
        <section id="hero" class="pt-24 h-[600px] bg-neutral-50">
            <div class="container mx-auto px-6 py-12">
                <div class="flex flex-col md:flex-row items-center">
                    <div class="md:w-1/2 mb-10 md:mb-0">
                        <h1 class="text-4xl md:text-5xl text-neutral-900 mb-6">Conectando talentos às melhores
                            oportunidades</h1>
                        <p class="text-xl text-neutral-600 mb-8">Somos especialistas em encontrar o profissional certo
                            para sua empresa e a vaga ideal para sua carreira.</p>
                        <div class="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                            <span
                                class="px-6 py-3 bg-neutral-800 text-white rounded-md text-center hover:bg-neutral-700 cursor-pointer"><a
                                    href="<?php echo route_to('site.vagas');?>">Ver Vagas Disponíveis</a></span>
                            <span
                                class="px-6 py-3 border border-neutral-300 rounded-md text-center hover:bg-neutral-50 cursor-pointer"><a
                                    href="<?php echo route_to('site.cadastre');?>">Cadastrar
                                    Currículo</a></span>

                        </div>
                    </div>
                    <div class="md:w-1/2 flex justify-center">
                        <div
                            class="w-full max-w-md bg-neutral-200 rounded-lg h-[300px] md:h-[400px] flex items-center justify-center">
                            <img src="<?php echo base_url('assets/img/rh.jpg'); ?>"
                                alt="Imagem de profissionais em ambiente corporativo">

                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="mission" class="py-16 bg-white">
            <div class="container mx-auto px-6">
                <div class="text-center mb-12">
                    <h2 class="text-3xl text-neutral-900 mb-4">Nossa Missão</h2>
                    <div class="w-16 h-1 bg-neutral-300 mx-auto mb-6"></div>
                    <p class="text-xl text-neutral-600 max-w-3xl mx-auto">Oferecer aos clientes soluções eficazes e
                        inovadoras na área de Recursos Humanos.</p>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
                    <div class="bg-neutral-50 p-6 rounded-lg shadow-sm">
                        <div class="w-14 h-14 bg-neutral-200 rounded-full flex items-center justify-center mb-4">
                            <i class="fa-solid fa-handshake text-neutral-700 text-2xl"></i>
                        </div>
                        <h3 class="text-xl mb-3">Compromisso</h3>
                        <p class="text-neutral-600">Trabalhamos com ética e transparência, buscando sempre os melhores
                            resultados para nossos clientes e candidatos.</p>
                    </div>

                    <div class="bg-neutral-50 p-6 rounded-lg shadow-sm">
                        <div class="w-14 h-14 bg-neutral-200 rounded-full flex items-center justify-center mb-4">
                            <i class="fa-solid fa-bullseye text-neutral-700 text-2xl"></i>
                        </div>
                        <h3 class="text-xl mb-3">Precisão</h3>
                        <p class="text-neutral-600">Utilizamos metodologias avançadas para garantir a compatibilidade
                            entre candidatos e vagas.</p>
                    </div>

                    <div class="bg-neutral-50 p-6 rounded-lg shadow-sm">
                        <div class="w-14 h-14 bg-neutral-200 rounded-full flex items-center justify-center mb-4">
                            <i class="fa-solid fa-rocket text-neutral-700 text-2xl"></i>
                        </div>
                        <h3 class="text-xl mb-3">Inovação</h3>
                        <p class="text-neutral-600">Estamos sempre atualizados com as tendências do mercado e novas
                            tecnologias de recrutamento.</p>
                    </div>
                </div>
            </div>
        </section>

        <section id="services" class="py-16 bg-neutral-50">
            <div class="container mx-auto px-6">
                <div class="text-center mb-12">
                    <h2 class="text-3xl text-neutral-900 mb-4">Nossos Serviços</h2>
                    <div class="w-16 h-1 bg-neutral-300 mx-auto mb-6"></div>
                    <p class="text-xl text-neutral-600 max-w-3xl mx-auto">Oferecemos soluções completas em recursos
                        humanos para empresas de todos os portes.</p>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
                    <div class="bg-white p-6 rounded-lg shadow-sm">
                        <div class="w-12 h-12 bg-neutral-200 rounded-full flex items-center justify-center mb-4">
                            <i class="fa-solid fa-magnifying-glass text-neutral-700"></i>
                        </div>
                        <h3 class="text-lg mb-3">Recrutamento e Seleção</h3>
                        <p class="text-neutral-600 mb-4">Identificamos e selecionamos os melhores talentos para sua
                            empresa.</p>
                        <span class="text-neutral-700 hover:text-neutral-900 flex items-center cursor-pointer">
                            Saiba mais <i class="fa-solid fa-arrow-right ml-2"></i>
                        </span>
                    </div>

                    <div class="bg-white p-6 rounded-lg shadow-sm">
                        <div class="w-12 h-12 bg-neutral-200 rounded-full flex items-center justify-center mb-4">
                            <i class="fa-solid fa-clipboard-check text-neutral-700"></i>
                        </div>
                        <h3 class="text-lg mb-3">Avaliação de Desempenho</h3>
                        <p class="text-neutral-600 mb-4">Desenvolvemos e implementamos sistemas de avaliação
                            personalizados.</p>
                        <span class="text-neutral-700 hover:text-neutral-900 flex items-center cursor-pointer">
                            Saiba mais <i class="fa-solid fa-arrow-right ml-2"></i>
                        </span>
                    </div>

                    <div class="bg-white p-6 rounded-lg shadow-sm">
                        <div class="w-12 h-12 bg-neutral-200 rounded-full flex items-center justify-center mb-4">
                            <i class="fa-solid fa-graduation-cap text-neutral-700"></i>
                        </div>
                        <h3 class="text-lg mb-3">Treinamento e Desenvolvimento</h3>
                        <p class="text-neutral-600 mb-4">Programas de capacitação para maximizar o potencial da sua
                            equipe.</p>
                        <span class="text-neutral-700 hover:text-neutral-900 flex items-center cursor-pointer">
                            Saiba mais <i class="fa-solid fa-arrow-right ml-2"></i>
                        </span>
                    </div>

                    <div class="bg-white p-6 rounded-lg shadow-sm">
                        <div class="w-12 h-12 bg-neutral-200 rounded-full flex items-center justify-center mb-4">
                            <i class="fa-solid fa-chart-line text-neutral-700"></i>
                        </div>
                        <h3 class="text-lg mb-3">Consultoria em RH</h3>
                        <p class="text-neutral-600 mb-4">Soluções estratégicas para otimizar a gestão de pessoas.</p>
                        <span class="text-neutral-700 hover:text-neutral-900 flex items-center cursor-pointer">
                            Saiba mais <i class="fa-solid fa-arrow-right ml-2"></i>
                        </span>
                    </div>
                </div>
            </div>
        </section>

        <section id="job-preview" class="py-16 bg-white">
            <div class="container mx-auto px-6">
                <div class="flex flex-col md:flex-row items-center justify-between">
                    <div class="md:w-1/2 mb-8 md:mb-0">
                        <h2 class="text-3xl text-neutral-900 mb-4">Vagas em Destaque</h2>
                        <p class="text-xl text-neutral-600 mb-6">Confira algumas das oportunidades disponíveis em nosso
                            banco de vagas.</p>

                        <div class="space-y-4 mb-8">

                            <?php foreach($alljobs as $job): ?>
                            <div class=" border border-neutral-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                                <div class="flex justify-between items-start">
                                    <div>
                                        <h3 class="text-lg"><?php echo ucfirst($job['name']); ?></h3>
                                        <p class="text-neutral-600"><?php echo ucfirst($job['location']); ?></p>
                                    </div>
                                    <span class="bg-neutral-100 text-neutral-700 px-2 py-1 text-sm rounded">CLT</span>
                                </div>
                            </div>
                            <?php endforeach ?>

                        </div>

                        <span
                            class="inline-block px-6 py-3 bg-neutral-800 text-white rounded-md hover:bg-neutral-700 cursor-pointer">Ver
                            todas as vagas</span>
                    </div>

                    <div class="md:w-5/12">
                        <div class="bg-neutral-200 rounded-lg h-[400px] flex items-center justify-center">
                            <span class="text-white text-lg">Imagem de pessoas em ambiente de trabalho</span>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="testimonials" class="py-16 bg-neutral-50">
            <div class="container mx-auto px-6">
                <div class="text-center mb-12">
                    <h2 class="text-3xl text-neutral-900 mb-4">O que nossos clientes dizem</h2>
                    <div class="w-16 h-1 bg-neutral-300 mx-auto mb-6"></div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div class="bg-white p-6 rounded-lg shadow-sm">
                        <div class="flex items-center mb-4">
                            <img src="https://api.dicebear.com/7.x/notionists/svg?scale=200&amp;seed=123" alt="Avatar"
                                class="w-12 h-12 rounded-full mr-4">
                            <div>
                                <h4>Carolina Silva</h4>
                                <p class="text-neutral-600 text-sm">Diretora de RH, TechCorp</p>
                            </div>
                        </div>
                        <p class="text-neutral-600">"A parceria com a HR Solutions transformou nosso processo de
                            recrutamento. Conseguimos reduzir o tempo de contratação em 40% e melhorar a qualidade dos
                            candidatos."</p>
                    </div>

                    <div class="bg-white p-6 rounded-lg shadow-sm">
                        <div class="flex items-center mb-4">
                            <img src="https://api.dicebear.com/7.x/notionists/svg?scale=200&amp;seed=456" alt="Avatar"
                                class="w-12 h-12 rounded-full mr-4">
                            <div>
                                <h4>Ricardo Mendes</h4>
                                <p class="text-neutral-600 text-sm">CEO, Inovação S.A.</p>
                            </div>
                        </div>
                        <p class="text-neutral-600">"Excelente atendimento e profissionais altamente qualificados.
                            Encontraram candidatos que se encaixaram perfeitamente na cultura da nossa empresa."</p>
                    </div>

                    <div class="bg-white p-6 rounded-lg shadow-sm">
                        <div class="flex items-center mb-4">
                            <img src="https://api.dicebear.com/7.x/notionists/svg?scale=200&amp;seed=789" alt="Avatar"
                                class="w-12 h-12 rounded-full mr-4">
                            <div>
                                <h4>Fernanda Costa</h4>
                                <p class="text-neutral-600 text-sm">Gerente de Pessoas, Grupo ABC</p>
                            </div>
                        </div>
                        <p class="text-neutral-600">"A consultoria em gestão de desempenho que recebemos foi fundamental
                            para reestruturar nosso departamento e melhorar os resultados da equipe."</p>
                    </div>
                </div>
            </div>
        </section>

        <section id="cta" class="py-16 bg-neutral-800 text-white">
            <div class="container mx-auto px-6 text-center">
                <h2 class="text-3xl mb-6">Pronto para transformar sua carreira ou equipe?</h2>
                <p class="text-xl mb-8 max-w-3xl mx-auto">Seja você um profissional em busca de novas oportunidades ou
                    uma empresa que precisa de talentos, estamos aqui para ajudar.</p>
                <div class="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-6">
                    <span class="px-6 py-3 bg-white text-neutral-800 rounded-md hover:bg-neutral-100 cursor-pointer">Ver
                        Vagas Disponíveis</span>
                    <span class="px-6 py-3 border border-white rounded-md hover:bg-neutral-700 cursor-pointer">Solicitar
                        Consultoria</span>
                </div>
            </div>
        </section>
    </main>

    <footer id="footer" class="bg-neutral-900 text-neutral-400">
        <div class="container mx-auto px-6 py-12">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div>
                    <div class="flex items-center space-x-2 mb-6">
                        <i class="fa-solid fa-users-gear text-white text-2xl"></i>
                        <span class="text-xl text-white">Belottis</span>
                    </div>
                    <p class="mb-6">Conectando talentos e oportunidades desde 2010.</p>
                    <div class="flex space-x-4">
                        <span class="text-neutral-400 hover:text-white cursor-pointer">
                            <a href="https://www.facebook.com/belottis/" target="blank"> <i
                                    class="fa-brands fa-facebook-f">
                                </i></a>
                        </span>
                        <span class="text-neutral-400 hover:text-white cursor-pointer">
                            <i class="fa-brands fa-twitter"></i>
                        </span>
                        <span class="text-neutral-400 hover:text-white cursor-pointer">
                            <i class="fa-brands fa-linkedin-in"></i>
                        </span>
                        <span class="text-neutral-400 hover:text-white cursor-pointer">
                            <i class="fa-brands fa-instagram"></i>
                        </span>
                    </div>
                </div>

                <div>
                    <h3 class="text-white text-lg mb-6">Links Rápidos</h3>
                    <ul class="space-y-3">
                        <li><span class="hover:text-white cursor-pointer">Início</span></li>
                        <li><span class="hover:text-white cursor-pointer">Quem Somos</span></li>
                        <li><span class="hover:text-white cursor-pointer">Serviços</span></li>
                        <li><span class="hover:text-white cursor-pointer">Vagas</span></li>
                        <li><span class="hover:text-white cursor-pointer">Cadastrar Currículo</span></li>
                    </ul>
                </div>

                <div>
                    <h3 class="text-white text-lg mb-6">Serviços</h3>
                    <ul class="space-y-3">
                        <li><span class="hover:text-white cursor-pointer">Recrutamento e Seleção</span></li>
                        <li><span class="hover:text-white cursor-pointer">Estágios</span></li>
                        <li><span class="hover:text-white cursor-pointer">Folha de Pagamento</span></li>
                        <li><span class="hover:text-white cursor-pointer">Treinamentos</span></li>

                    </ul>
                </div>

                <div>
                    <h3 class="text-white text-lg mb-6">Contato</h3>
                    <ul class="space-y-3">
                        <li class="flex items-center">
                            <i class="fa-solid fa-location-dot mr-3"></i>
                            <span>Rua Jamil João Zarif, 264 - Sala 4
                                CEP:07143-000 - Guarulhos / SP</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fa-solid fa-phone mr-3"></i>
                            <span>(11) 2600-1607</span>
                            <span>(11) 94632-6003</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fa-solid fa-envelope mr-3"></i>
                            <span>contato@belottis.com.br</span>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="border-t border-neutral-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
                <p>© 2025 HR Solutions. Todos os direitos reservados. Desenvolvido por <a
                        href="https://fredericomoura.com.br">Frederico Moura</a></p>
                <div class="flex space-x-6 mt-4 md:mt-0">
                    <span class="hover:text-white cursor-pointer">Política de Privacidade</span>
                    <span class="hover:text-white cursor-pointer">Termos de Uso</span>
                    <span class="hover:text-white cursor-pointer">Cookies</span>
                </div>
            </div>
        </div>
    </footer>


</body>

</html>